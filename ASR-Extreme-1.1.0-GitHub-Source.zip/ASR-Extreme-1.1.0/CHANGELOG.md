# Changelog

## 1.1.0
- Reworked the Russian-language control-center screen with clearer device, GPU, graphics API, memory, thermal and battery diagnostics.
- Added a permission-aware notification startup flow for Android 13+.
- Improved the foreground monitor: thermal event callbacks where supported, battery-temperature reporting, tappable notification and explicit stop action.
- Reduced unnecessary GL probe work by using a one-shot render request and removing the probe surface after detection.
- Cached the native Vulkan probe result instead of recreating a Vulkan instance on every screen refresh.
- Clarified that render presets are recommendations for games that integrate an upscaler, not system-wide game modifications.

## 1.0.0
- Initial Android diagnostics and user-started thermal monitoring baseline.
