#include <jni.h>
#include <vulkan/vulkan.h>
#include <sstream>
#include <string>
#include <vector>

static std::string queryVulkan() {
    uint32_t loaderVersion = VK_API_VERSION_1_0;
    auto enumerateVersion =
        reinterpret_cast<PFN_vkEnumerateInstanceVersion>(
            vkGetInstanceProcAddr(VK_NULL_HANDLE, "vkEnumerateInstanceVersion"));

    if (enumerateVersion != nullptr) {
        if (enumerateVersion(&loaderVersion) != VK_SUCCESS) {
            loaderVersion = VK_API_VERSION_1_0;
        }
    }

    VkApplicationInfo appInfo{};
    appInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    appInfo.pApplicationName = "ASR Control Center";
    appInfo.applicationVersion = VK_MAKE_VERSION(1, 0, 0);
    appInfo.pEngineName = "ASR Diagnostics";
    appInfo.engineVersion = VK_MAKE_VERSION(1, 0, 0);
    appInfo.apiVersion = loaderVersion;

    VkInstanceCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    createInfo.pApplicationInfo = &appInfo;

    VkInstance instance = VK_NULL_HANDLE;
    VkResult createResult = vkCreateInstance(&createInfo, nullptr, &instance);

    std::ostringstream out;
    out << "Vulkan loader: "
        << VK_VERSION_MAJOR(loaderVersion) << "."
        << VK_VERSION_MINOR(loaderVersion) << "."
        << VK_VERSION_PATCH(loaderVersion);

    if (createResult != VK_SUCCESS || instance == VK_NULL_HANDLE) {
        out << "\nVulkan instance: unavailable (VkResult "
            << static_cast<int>(createResult) << ")";
        return out.str();
    }

    uint32_t deviceCount = 0;
    VkResult countResult = vkEnumeratePhysicalDevices(instance, &deviceCount, nullptr);
    if (countResult != VK_SUCCESS || deviceCount == 0) {
        out << "\nPhysical GPU: not enumerated";
        vkDestroyInstance(instance, nullptr);
        return out.str();
    }

    std::vector<VkPhysicalDevice> devices(deviceCount);
    VkResult devicesResult =
        vkEnumeratePhysicalDevices(instance, &deviceCount, devices.data());

    if (devicesResult == VK_SUCCESS) {
        for (uint32_t i = 0; i < deviceCount; ++i) {
            VkPhysicalDeviceProperties props{};
            vkGetPhysicalDeviceProperties(devices[i], &props);
            out << "\nGPU " << (i + 1) << ": " << props.deviceName
                << "\nAPI: "
                << VK_VERSION_MAJOR(props.apiVersion) << "."
                << VK_VERSION_MINOR(props.apiVersion) << "."
                << VK_VERSION_PATCH(props.apiVersion)
                << "\nVendor ID: 0x" << std::hex << props.vendorID
                << " | Device ID: 0x" << props.deviceID << std::dec
                << "\nDriver version: " << props.driverVersion;
        }
    } else {
        out << "\nPhysical GPU: enumeration failed (VkResult "
            << static_cast<int>(devicesResult) << ")";
    }

    vkDestroyInstance(instance, nullptr);
    return out.str();
}

extern "C" JNIEXPORT jstring JNICALL
Java_dev_asr_mobile_NativeAsr_getVulkanInfo(JNIEnv* env, jobject) {
    const std::string result = queryVulkan();
    return env->NewStringUTF(result.c_str());
}
