package dev.asr.mobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/** User-started foreground service for transparent thermal/battery monitoring only. */
class AsrMonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var notificationManager: NotificationManager
    private val channelId = "asr_monitor"
    private var thermalListenerRegistered = false

    private val refreshTask = object : Runnable {
        override fun run() {
            updateNotification()
            handler.postDelayed(this, REFRESH_INTERVAL_MS)
        }
    }

    private val thermalListener = PowerManager.OnThermalStatusChangedListener { updateNotification() }

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopMonitoring()
            return START_NOT_STICKY
        }
        val notification = buildNotification("Мониторинг устройства активен")
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else startForeground(NOTIFICATION_ID, notification)
        } catch (e: Exception) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        registerThermalListener()
        handler.removeCallbacks(refreshTask)
        handler.post(refreshTask)
        return START_NOT_STICKY
    }

    private fun registerThermalListener() {
        if (Build.VERSION.SDK_INT >= 29 && !thermalListenerRegistered) {
            try {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                pm.addThermalStatusListener(thermalListener)
                thermalListenerRegistered = true
            } catch (_: Exception) { /* Periodic polling remains available. */ }
        }
    }

    private fun unregisterThermalListener() {
        if (Build.VERSION.SDK_INT >= 29 && thermalListenerRegistered) {
            try {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                pm.removeThermalStatusListener(thermalListener)
            } catch (_: Exception) { }
            thermalListenerRegistered = false
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(refreshTask)
        unregisterThermalListener()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun updateNotification() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val thermal = if (Build.VERSION.SDK_INT >= 29) thermalName(pm.currentThermalStatus) else "н/д"
        val battery = try {
            val state = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val temp = state?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
            if (temp > 0) String.format(java.util.Locale.US, "%.1f°C", temp / 10f) else "н/д"
        } catch (_: Exception) { "н/д" }
        notificationManager.notify(NOTIFICATION_ID, buildNotification("Нагрев: $thermal · батарея: $battery"))
    }

    private fun thermalName(status: Int) = when (status) {
        PowerManager.THERMAL_STATUS_NONE -> "норма"
        PowerManager.THERMAL_STATUS_LIGHT -> "лёгкий"
        PowerManager.THERMAL_STATUS_MODERATE -> "умеренный"
        PowerManager.THERMAL_STATUS_SEVERE -> "сильный"
        PowerManager.THERMAL_STATUS_CRITICAL -> "критический"
        PowerManager.THERMAL_STATUS_EMERGENCY -> "аварийный"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "отключение"
        else -> "неизвестно"
    }

    private fun buildNotification(message: String): Notification {
        val stopIntent = Intent(this, AsrMonitorService::class.java).apply { action = ACTION_STOP }
        val pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT or
            if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val stopPending = PendingIntent.getService(this, 0, stopIntent, pendingFlags)
        val openPending = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), pendingFlags
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder.setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
            .setContentTitle("ASR Extreme")
            .setContentText(message)
            .setContentIntent(openPending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_pause, "Остановить", stopPending)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "ASR мониторинг", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Постоянное уведомление во время мониторинга температуры"
            channel.setShowBadge(false)
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun stopMonitoring() {
        handler.removeCallbacks(refreshTask)
        unregisterThermalListener()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    companion object {
        const val ACTION_STOP = "dev.asr.mobile.action.STOP_MONITOR"
        private const val NOTIFICATION_ID = 2101
        private const val REFRESH_INTERVAL_MS = 60_000L
    }
}
