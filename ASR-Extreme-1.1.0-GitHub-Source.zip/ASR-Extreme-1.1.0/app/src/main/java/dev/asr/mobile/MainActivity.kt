package dev.asr.mobile

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.app.ActivityManager
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var gpuText: TextView
    private lateinit var apiText: TextView
    private lateinit var systemText: TextView
    private lateinit var recommendationText: TextView
    private lateinit var statusText: TextView
    private lateinit var startButton: Button
    private var rendererName = "Определение GPU…"
    private var glVersion = "Проверка OpenGL ES…"
    private var monitorStartedAfterPermission = false
    private var vulkanRuntimeCache: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 18, 31)
        window.navigationBarColor = Color.rgb(10, 18, 31)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
            setBackgroundColor(Color.rgb(10, 18, 31))
        }
        root.addView(label("ASR EXTREME", 26f, Color.WHITE, true))
        root.addView(label("ANDROID GRAPHICS CONTROL CENTER · 1.1.0", 11f, Color.LTGRAY))
        root.addView(space(18))

        root.addView(sectionTitle("СОСТОЯНИЕ УСТРОЙСТВА"))
        gpuText = label("GPU: ожидание…", 15f, Color.WHITE)
        apiText = label("Графика: проверка…", 13f, Color.LTGRAY)
        systemText = label("Система: сбор данных…", 13f, Color.LTGRAY)
        recommendationText = label("Рекомендация: анализ…", 14f, Color.WHITE, true)
        statusText = label("Статус: готово к диагностике", 12f, Color.rgb(135, 220, 175))
        root.addView(card(gpuText, apiText, systemText, recommendationText, statusText))
        root.addView(space(18))

        root.addView(sectionTitle("ПРОФИЛЬ ДЛЯ ИГРОВОГО РЕНДЕРЕРА"))
        val profileInfo = label(
            "Профиль — рекомендация для игры, которая отдельно поддерживает интеграцию апскейлера. " +
                "Это приложение не может принудительно менять разрешение сторонних игр.",
            12f, Color.LTGRAY
        )
        root.addView(profileInfo)
        val modes = listOf("Quality · 0.80x", "Balanced · 0.67x", "Performance · 0.50x", "Ultra · 0.40x")
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, modes)
            setSelection(1)
        }
        root.addView(spinner)
        root.addView(space(18))

        root.addView(sectionTitle("ФОНОВЫЙ МОНИТОРИНГ"))
        root.addView(label(
            "По запросу отслеживает тепловой статус Android и показывает постоянное уведомление. " +
                "Не разгоняет CPU/GPU, не меняет частоты и не вмешивается в другие приложения.",
            12f, Color.LTGRAY
        ))
        root.addView(space(8))
        startButton = Button(this).apply {
            text = "Включить мониторинг"
            setOnClickListener { requestPermissionAndStart() }
        }
        root.addView(startButton)
        root.addView(Button(this).apply {
            text = "Остановить мониторинг"
            setOnClickListener {
                stopService(Intent(this@MainActivity, AsrMonitorService::class.java))
                statusText.text = "Статус: команда остановки отправлена"
            }
        })
        root.addView(Button(this).apply {
            text = "Обновить диагностику"
            setOnClickListener { updateDeviceInfo() }
        })
        root.addView(space(18))
        root.addView(label(
            "ВАЖНО: настоящий временной апскейлинг требует доступа к кадрам, depth buffer, motion vectors и jitter " +
                "внутри игрового движка. Генерация кадров и универсальный системный DLSS здесь не заявляются.",
            11f, Color.GRAY
        ))

        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
        probeGpu()
        updateDeviceInfo()
    }

    override fun onResume() {
        super.onResume()
        updateDeviceInfo()
    }

    private fun requestPermissionAndStart() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            monitorStartedAfterPermission = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
            return
        }
        startMonitor()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_NOTIFICATIONS && monitorStartedAfterPermission) {
            monitorStartedAfterPermission = false
            // Android permits starting an FGS without notification permission, but the notification
            // is not normally visible in the notification drawer. Require consent for clear UX.
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startMonitor()
            else statusText.text = "Статус: разрешение на уведомления не выдано"
        }
    }

    private fun startMonitor() {
        val intent = Intent(this, AsrMonitorService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            statusText.text = "Статус: запуск фонового мониторинга запрошен"
        } catch (e: Exception) {
            statusText.text = "Статус: не удалось запустить мониторинг (${e.javaClass.simpleName})"
        }
    }

    private fun probeGpu() {
        val glView = GLSurfaceView(this)
        glView.setEGLContextClientVersion(3)
        glView.setRenderer(object : GLSurfaceView.Renderer {
            override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
                rendererName = GLES20.glGetString(GLES20.GL_RENDERER) ?: "Неизвестно"
                glVersion = GLES20.glGetString(GLES20.GL_VERSION) ?: "Неизвестно"
                runOnUiThread {
                    updateDeviceInfo()
                    (glView.parent as? ViewGroup)?.removeView(glView)
                }
            }
            override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) = Unit
            override fun onDrawFrame(gl: GL10?) = Unit
        })
        glView.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
        glView.alpha = 0f
        glView.layoutParams = ViewGroup.LayoutParams(1, 1)
        (window.decorView as? ViewGroup)?.addView(glView)
    }

    private fun updateDeviceInfo() {
        if (!::gpuText.isInitialized) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memory)
        val availableMb = memory.availMem / (1024L * 1024L)
        val totalMb = memory.totalMem / (1024L * 1024L)
        val thermalCode = if (Build.VERSION.SDK_INT >= 29) pm.currentThermalStatus else -1
        val thermal = thermalLabel(thermalCode)
        val batteryTemp = batteryTemperatureC()
        val vulkanFeature = packageManager.hasSystemFeature("android.hardware.vulkan.version")
        val vulkanRuntime = vulkanRuntimeCache ?: try {
            NativeAsr.getVulkanInfo().also { vulkanRuntimeCache = it }
        } catch (t: Throwable) {
            "Нативная проверка Vulkan недоступна: ${t.javaClass.simpleName}".also { vulkanRuntimeCache = it }
        }
        val vendor = when {
            rendererName.contains("Adreno", true) -> "Qualcomm Adreno"
            rendererName.contains("Mali", true) -> "Arm Mali"
            rendererName.contains("Immortalis", true) -> "Arm Immortalis"
            rendererName.contains("PowerVR", true) -> "PowerVR"
            else -> "Не определён"
        }
        val recommendation = when {
            thermalCode >= PowerManager.THERMAL_STATUS_SEVERE -> "Thermal Safe · снизить графическую нагрузку"
            thermalCode == PowerManager.THERMAL_STATUS_MODERATE -> "Balanced · следить за нагревом"
            availableMb < 700L -> "Performance · закрыть лишние приложения"
            else -> "Balanced · безопасная стартовая рекомендация"
        }
        gpuText.text = "GPU: $rendererName\nКласс: $vendor"
        apiText.text = "OpenGL ES: $glVersion\nVulkan feature: ${if (vulkanFeature) "объявлен системой" else "не объявлен"}\n$vulkanRuntime"
        systemText.text = "Устройство: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\nRAM доступно: ${availableMb} МБ / ${totalMb} МБ\nНагрев: $thermal · батарея: ${batteryTemp ?: "н/д"}"
        recommendationText.text = "Рекомендация: $recommendation"
        statusText.text = "Диагностика обновлена · ${if (rendererName.startsWith("Определение")) "GPU ещё определяется" else "GPU обнаружен"}"
    }

    private fun batteryTemperatureC(): String? = try {
        val intent = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val tenths = intent?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        if (tenths > 0) String.format(Locale.US, "%.1f °C", tenths / 10f) else null
    } catch (_: Exception) { null }

    private fun thermalLabel(status: Int): String = when (status) {
        PowerManager.THERMAL_STATUS_NONE -> "норма"
        PowerManager.THERMAL_STATUS_LIGHT -> "лёгкий"
        PowerManager.THERMAL_STATUS_MODERATE -> "умеренный"
        PowerManager.THERMAL_STATUS_SEVERE -> "сильный"
        PowerManager.THERMAL_STATUS_CRITICAL -> "критический"
        PowerManager.THERMAL_STATUS_EMERGENCY -> "аварийный"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "отключение"
        else -> "недоступен"
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }
    private fun sectionTitle(text: String) = label(text, 11f, Color.rgb(116, 180, 255), true)
    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }
    private fun card(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.START
        setPadding(dp(16), dp(12), dp(16), dp(12))
        setBackgroundColor(Color.rgb(24, 39, 59))
        views.forEach { addView(it) }
    }

    companion object { private const val REQUEST_NOTIFICATIONS = 501 }
}
