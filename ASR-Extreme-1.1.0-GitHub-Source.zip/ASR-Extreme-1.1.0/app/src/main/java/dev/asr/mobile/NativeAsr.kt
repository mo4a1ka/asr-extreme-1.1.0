package dev.asr.mobile

/**
 * Reports Vulkan loader API support only.
 * This does not prove that a specific game exposes the resources required by an upscaler.
 */
object NativeAsr {
    init { System.loadLibrary("asr_native") }
    external fun getVulkanInfo(): String
}
