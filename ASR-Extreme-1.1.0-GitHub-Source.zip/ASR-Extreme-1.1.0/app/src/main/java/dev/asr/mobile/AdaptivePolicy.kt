package dev.asr.mobile

enum class AsrPreset(val scale: Float) {
    QUALITY(0.80f),
    BALANCED(0.67f),
    PERFORMANCE(0.50f),
    ULTRA_PERFORMANCE(0.40f)
}

data class FrameSample(
    val frameTimeMs: Float,
    val thermalStatus: Int,
    val availableMemoryMb: Long
)

object AdaptivePolicy {
    /**
     * Conservative recommendation policy for the Redmi 15C test target.
     * The scale is a suggested render scale for an integrated game renderer,
     * not a system-wide setting. It must be validated on-device.
     */
    fun recommend(sample: FrameSample): AsrPreset {
        if (sample.thermalStatus >= 4) return AsrPreset.ULTRA_PERFORMANCE
        if (sample.thermalStatus >= 3) return AsrPreset.PERFORMANCE
        if (sample.availableMemoryMb < 700L) return AsrPreset.PERFORMANCE

        return when {
            sample.frameTimeMs > 33.3f -> AsrPreset.ULTRA_PERFORMANCE
            sample.frameTimeMs > 25.0f -> AsrPreset.PERFORMANCE
            sample.frameTimeMs > 18.0f -> AsrPreset.BALANCED
            else -> AsrPreset.QUALITY
        }
    }
}
