# ASR Extreme — Android Control Center 1.1.0

Android app project for device diagnostics and user-started background thermal monitoring.
Initial target: Redmi 15C, user-reported 8 GB RAM, Android 15, Helio G81-Ultra / Mali-G52 MC2.

## What works in this release

- Android app UI and quality-profile selector (UI only).
- OpenGL ES renderer identification.
- Native Vulkan instance creation and physical-device enumeration.
- Android thermal-state, available-memory and battery-temperature diagnostics.
- User-started foreground service with a persistent notification, Stop action and thermal-change callbacks where supported.
- Notification-permission flow for Android 13+ and a one-shot OpenGL ES GPU probe.
- GitHub Actions workflow that builds an ARM64 debug APK and uploads it as an artifact.

## What this app does NOT do

- It does not apply upscaling to arbitrary installed games.
- It does not inject into other apps or capture their screens.
- It does not generate extra frames.
- The included compute shader is a starter shader, not a production upscaler.
- The preset selector is not yet connected to a game's render resolution.

Real temporal upscaling needs game-renderer inputs such as color, depth, motion vectors,
camera jitter and frame timing. Arm ASR documents these integration requirements:
https://github.com/arm/accuracy-super-resolution-generic-library

## Build locally

Requirements: Android Studio, JDK 17, Android SDK Platform 35, NDK 27.2.12479018,
and CMake 3.22.1.

Open the project in Android Studio, sync Gradle, then run `:app:assembleDebug`.

Or use Gradle 8.9:
`gradle --no-daemon :app:assembleDebug`

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Build on GitHub

The workflow `.github/workflows/android.yml` builds the debug APK on pushes, pull
requests, and manual dispatch. Open **Actions** on the repository and download the
`ASR-Extreme-debug-apk` artifact from a successful run.

See `GITHUB_RELEASE.md` for publishing steps.

## Background mode

The app provides an explicitly user-started foreground service with a persistent
notification. It monitors Android thermal status and battery temperature; it does not
run a hidden game optimizer. The service is user-started, returns `START_NOT_STICKY`,
and stops when requested. Android may limit background services, and distribution
of `specialUse` foreground services is subject to platform policy review.

## Version boundaries

ASR Control Center is version 1.1.0 as a diagnostics/monitoring app. The integrated
upscaling SDK is still an engine-integration project and is not represented as a
completed universal game enhancer. Validate the APK on real Adreno and Mali devices
before describing device support as verified.
