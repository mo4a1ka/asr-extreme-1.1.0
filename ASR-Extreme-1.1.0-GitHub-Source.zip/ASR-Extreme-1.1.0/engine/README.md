# ASR Engine — Redmi 15C bring-up

Target: Mali-G52 MC2 / Helio G81-Ultra / ARM64 / Android 15 (reported 8 GB RAM).

## Stage A: capability discovery

Query at runtime rather than assuming support:
- Vulkan instance and physical-device API versions
- device name, vendor ID, device ID and driver version
- supported extensions and features
- optimal image formats and usage flags
- device-local and host-visible memory heaps
- timestamp queries and queue families

The current native probe reports the Vulkan loader API version only. It is not yet
a physical-device capability report.

## Stage B: performance-first spatial path

Start with one low-resolution color image and one output image. Use a compute or
fragment pass and avoid CPU readback. Reuse image allocations across frames. Benchmark
at the device's actual display size (Redmi 15C is listed with a 1600x720 panel).

The included shader is a correctness baseline (bilinear sampling), not a quality
upscaler. It can look softer than native rendering and may not be faster on every
GPU/driver combination.

## Stage C: temporal path

Arm ASR requires game-renderer inputs such as color, depth, motion vectors, camera
jitter and frame delta. It is not possible to reconstruct those reliably from an
arbitrary app's final screen image alone.

Reference:
https://github.com/arm/accuracy-super-resolution-generic-library
