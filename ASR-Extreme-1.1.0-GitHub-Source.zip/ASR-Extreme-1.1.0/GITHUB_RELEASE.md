# GitHub release checklist

1. Create an empty GitHub repository and upload the contents of this folder, including the hidden `.github` directory.
2. Push the default branch as `main`.
3. Open **Actions** and run **Android APK** (or push a commit to `main`).
4. Download the `ASR-Extreme-debug-apk` artifact from a successful workflow run.
5. Install the debug APK on a test device and verify GPU detection, Vulkan diagnostics, notification permission flow, foreground notification, thermal updates and Stop action.

The CI artifact is a **debug APK**, not a Play Store-ready signed release. To publish a signed release, create a protected Android signing keystore and store its credentials as GitHub Actions secrets. Never commit a keystore or passwords to the repository.

## Before calling this a production release

- Build and install on physical Adreno and Mali devices.
- Confirm behavior on Android 13, 14 and 15, including notification denial and battery restrictions.
- Run Android Lint and verify foreground-service policy eligibility for the intended distribution channel.
- Integrate and benchmark the Arm ASR SDK inside a supported game engine; this control-center app alone cannot upscale unrelated apps.
